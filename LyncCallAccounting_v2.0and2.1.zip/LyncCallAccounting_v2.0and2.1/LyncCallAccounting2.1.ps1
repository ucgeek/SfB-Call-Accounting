﻿#
# This script queries the Lync CDR database (LcsCDR) calculating useful information for call accounting
#
# AUTHOR: Andrew Morpeth
# DATE: 5th August 2014
# VERSION: v2.1
# INFORMATION: http://www.lync.geek.nz/p/call-accounting.html
#
# VERSION HISTORY
#    V 0.2 - Feb 2014 - beta: 1st release
#    V 0.3 - Feb 2014 - beta: Moved data processing to SQL using temporay tables
#    V 0.4 - Mar 2014 - beta: Moved functions outside of script
#    V 0.5 - Mar 2014 - beta: Added vendor rate card lookup and csv gateway import
#    V 0.6 - Mar 2014 - beta: Added support for Lync 2010 Monitoring server reports
#    V 0.7 - Mar 2014 - beta: Removed requirement for vendor rate card and gateways csv. If RateCard.csv or Gateways.csv dont exist and empty table will be created.
#    V 1.0 - Mar 2014 - beta: Added call cost calculations, commented SQL query, prepared restructured version for release
#    V 2.0 - June 2014 - stable: Minor bug fixes and improvements, tested in production for 3 months
#    V 2.1 - June 2014 - stable: Added better error checking, error output and debug mode
#
# NOTES
#    - Tested on Lync 2013 FE with SQL 2008 R2 and SQL 2012 monitoring databases and Lync 2010 FE with SQL 2008 R2 monitoring databases 
#    - Tested with a user account with Domain Admin and SQL sysadmin rights
#
# PREREQUISITES
# The script should be run from a Lync Front End server with the follow pre-requisites: 
#    - SQL Server Management Studio installed or Shared Management Objects.msi from the SQL Server feature pack
#    - User account which is a member of CSAdministrator and is a SQL db_owner or sysadmin
#
# USE (example below)
# LyncCallAccounting `
# -StartDate <Start Date> `
# -EndDate <End Date> `
# -CSVExportPath <File Path to save CSV> `
# -RateLocalCallingArea <Rate for local calls e.g. 0.05> `
# -DbGateways <optional: DROP|UseExisting> `
# -DbUsers <optional: DROP|UseExisting> `
# -DbRateCard <optional: DROP|UseExisting> `
# -RateCardCSV <File Path to RateCard CSV file> `
# -GatewaysCSV <File Path to Gateways CSV file> `
# -ADPath <AD search scope for Lync objects e.g. DC=domain,DC=co,DC=nz> `
# -SQLDataSource_LyncMonitoring <Monitoring SQL server e.g. MonitoringDbServer\Instance> `
# -LyncPool <Lync Pool FQDN>
# -SQLScriptPath <Path to LyncCallAccounting.sql>
# -DebugMode <$true|$false>
#
# This script is provided as-is, no warranty is provided or implied. The author is NOT responsible for any damages or data loss that may occur
# through the use of this script.  Always test before using in a production environment. This script is free to use for both personal and 
# business use, however, it may not be sold or included as part of a package that is for sale. A Service Provider may include this script 
# as part of their service offering/best practices provided they only charge for their time to implement and support. 
#
###########################################################################


##SETTINGS
#region settings
$startDTM = (Get-Date) #Get script start time
$SQLDatabase_LcsCDR = "LcsCDR" #Database to query. LcsCDR is the Lync monitoring CDR database.
$SQLDatabase_tempdb = "tempdb" #Database to create temporary tables
[bool]$script:ModulesLoaded = $false
#endregion

function StatusLog ($LogText, $Debug)
{
	if ($LogText -notlike "STEP:*")
	{
		if ($LogText -like "ERROR:*")
        {
            write-host " --> $LogText" -ForegroundColor Red
        }
		else
        {
            write-host " --> $LogText"
        }
	}
	else
	{
		write-host "$LogText"
	}
	if ($DebugMode -eq $true -and $Debug)
	{
		write-host " --> DEBUG: $Debug" -ForegroundColor Yellow
	}
}

function Import-RequiredModules
{
	StatusLog "STEP: Load required PowerShell Modules"
	try
	{
		#Import Lync module
		if (Get-Command New-CsExUmContact -errorAction SilentlyContinue)
		{
			StatusLog "Lync Commandlets already loaded..."
		}
		else
		{
			if (get-module -ListAvailable | where { $_.name -eq "Lync" })
			{
				StatusLog "Loading Lync Commandlets (Import-Module Lync)..."
				Import-Module Lync
			}
			elseif ($LyncPool)
			{
				#Remote connect to Lync if you are not running the script on a Lync server. Note that you may need to enable PS Remoting on the remote Lync server - Enable-PSRemoting (as admin)
				StatusLog "Loading Lync Commandlets (PS Remoting)..."
				$RemoteLync2013Session = New-PSSession -ConnectionUri https://$LyncPool/OCSPowerShell/ -Authentication Negotiate #-Credential (Get-credential)
				Import-PSSession $RemoteLync2013Session
			}
			else
			{
				StatusLog "ERROR: Unable to load Lync PowerShell module"
			}
		}
	}
	catch
	{
		$ex = $_.Exception
		StatusLog "ERROR: There was an error while checking or loading Lync PowerShell modules" $ex.Message
	}
	try
	{
		#Import AD module
		#Import Active Directory module (if not using PS 3.0 this is required. Importing module requires Remote Server Administration Tools > Role Administration Tools > AD DS and AD LDS Tools > Active Directory Module for Windows PowerShell to be installed)
		if (Get-Command New-ADObject -errorAction SilentlyContinue)
		{
			StatusLog "AD Commandlets already loaded..."
		}
		else
		{
			if (get-module -ListAvailable | where { $_.name -eq "ActiveDirectory" })
			{
				StatusLog "Loading AD Commandlets (Import-Module ActiveDirectory)..."
				Import-Module ActiveDirectory
			}
			else
			{
				StatusLog "ERROR: Unable to load ActiveDirectory module"
			}
		}
	}
	catch
	{
		$ex = $_.Exception
		StatusLog "ERROR: There was an error checking or loading the Active Directory PowerShell module" $ex.Message
	}
	[bool]$script:ModulesLoaded = $true
}

function Get-SqlType
{
	param ([string]$TypeName)
	
	try
	{
		switch ($TypeName)
		{
			'Boolean' { [Data.SqlDbType]::Bit }
			'Byte[]' { [Data.SqlDbType]::VarBinary }
			'Byte'  { [Data.SQLDbType]::VarBinary }
			'Datetime'  { [Data.SQLDbType]::DateTime }
			'Decimal' { [Data.SqlDbType]::Decimal }
			'Double' { [Data.SqlDbType]::Float }
			'Guid' { [Data.SqlDbType]::UniqueIdentifier }
			'Int16'  { [Data.SQLDbType]::SmallInt }
			'Int32'  { [Data.SQLDbType]::Int }
			'Int64' { [Data.SqlDbType]::BigInt }
			'UInt16'  { [Data.SQLDbType]::SmallInt }
			'UInt32'  { [Data.SQLDbType]::Int }
			'UInt64' { [Data.SqlDbType]::BigInt }
			'Single' { [Data.SqlDbType]::Decimal }
			default { [Data.SqlDbType]::VarChar }
		}
	}
	catch
	{
		$ex = $_.Exception
		StatusLog "ERROR: There was a error while running the Get-SQLType command" $ex.Message
	}
	
}

function Add-SqlTable
{
	[CmdletBinding()]
	param (
		[Parameter(Position = 0, Mandatory = $true)] [string]$ServerInstance,
		[Parameter(Position = 1, Mandatory = $true)] [string]$Database,
		[Parameter(Position = 2, Mandatory = $true)] [String]$TableName,
		[Parameter(Position = 3, Mandatory = $true)] [System.Data.DataTable]$DataTable,
		[Parameter(Position = 4, Mandatory = $false)] [string]$Username,
		[Parameter(Position = 5, Mandatory = $false)] [string]$Password,
		[ValidateRange(0, 8000)]
		[Parameter(Position = 6, Mandatory = $false)] [Int32]$MaxLength = 1000,
		[Parameter(Position = 7, Mandatory = $false)] [switch]$AsScript,
		[Parameter(Position = 8, Mandatory = $false)] [string]$ColumnCollation = ""
	)
	#[Parameter(Position=3, Mandatory=$true)] [System.Data.DataTable]$DataTable,
	
	try
	{
		add-type -AssemblyName "Microsoft.SqlServer.ConnectionInfo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -EA Stop
	}
	catch
	{
		add-type -AssemblyName "Microsoft.SqlServer.ConnectionInfo"
	}
	
	try
	{
		add-type -AssemblyName "Microsoft.SqlServer.Smo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -EA Stop
	}
	catch
	{
		add-type -AssemblyName "Microsoft.SqlServer.Smo"
	}
	
	try
	{
		if ($Username)
		{ $con = new-object ("Microsoft.SqlServer.Management.Common.ServerConnection") $ServerInstance, $Username, $Password }
		else
		{ $con = new-object ("Microsoft.SqlServer.Management.Common.ServerConnection") $ServerInstance }
		
		try
		{
			$con.Connect()
		}
		catch
		{
			$ex = $_.Exception
			StatusLog "ERROR: Could not connect to database while running Add-SQLtable" $ex.Message
		}
		
		$server = new-object ("Microsoft.SqlServer.Management.Smo.Server") $con
		$db = $server.Databases[$Database]
		$table = new-object ("Microsoft.SqlServer.Management.Smo.Table") $db, $TableName
		
		foreach ($column in $DataTable.Columns)
		{
			$sqlDbType = [Microsoft.SqlServer.Management.Smo.SqlDataType]"$(Get-SqlType $column.DataType.Name)"
			if ($sqlDbType -eq 'VarBinary' -or $sqlDbType -eq 'VarChar')
			{
				if ($MaxLength -gt 0)
				{ $dataType = new-object ("Microsoft.SqlServer.Management.Smo.DataType") $sqlDbType, $MaxLength }
				else
				{
					$sqlDbType = [Microsoft.SqlServer.Management.Smo.SqlDataType]"$(Get-SqlType $column.DataType.Name)Max"
					$dataType = new-object ("Microsoft.SqlServer.Management.Smo.DataType") $sqlDbType
				}
			}
			else
			{ $dataType = new-object ("Microsoft.SqlServer.Management.Smo.DataType") $sqlDbType }
			$col = new-object ("Microsoft.SqlServer.Management.Smo.Column") $table, $column.ColumnName, $dataType
			$col.Nullable = $column.AllowDBNull
			$col.Collation = $ColumnCollation
			$table.Columns.Add($col)
		}
		
		if ($AsScript)
		{
			$table.Script()
		}
		else
		{
			$table.Create()
		}
	}
	catch
	{
		$ex = $_.Exception
		StatusLog "ERROR: There was an error while running the Add-SQLtable command" $ex.Message
	}
	
}

function Invoke-Sqlcmd2
{
	[CmdletBinding()]
	param (
		[Parameter(Position = 0, Mandatory = $true)] [string]$ServerInstance,
		[Parameter(Position = 1, Mandatory = $false)] [string]$Database,
		[Parameter(Position = 2, Mandatory = $false)] [string]$Query,
		[Parameter(Position = 3, Mandatory = $false)] [string]$Username,
		[Parameter(Position = 4, Mandatory = $false)] [string]$Password,
		[Parameter(Position = 5, Mandatory = $false)] [Int32]$QueryTimeout = 14400,
		[Parameter(Position = 6, Mandatory = $false)] [Int32]$ConnectionTimeout = 15,
		[Parameter(Position = 7, Mandatory = $false)] [ValidateScript({ test-path $_ })] [string]$InputFile,
		[Parameter(Position = 8, Mandatory = $false)] [ValidateSet("DataSet", "DataTable", "DataRow")] [string]$As = "DataTable"
	)
	
	try
	{
		if ($InputFile)
		{
			$filePath = $(resolve-path $InputFile).path
			$Query = [System.IO.File]::ReadAllText("$filePath")
		}
		
		$conn = new-object System.Data.SqlClient.SQLConnection
		
		if ($Username)
		{ $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance, $Database, $Username, $Password, $ConnectionTimeout }
		else
		{ $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance, $Database, $ConnectionTimeout }
		
		$conn.ConnectionString = $ConnectionString
		
		#Following EventHandler is used for PRINT and RAISERROR T-SQL statements. Executed when -Verbose parameter specified by caller
		if ($PSBoundParameters.Verbose)
		{
			$conn.FireInfoMessageEventOnUserErrors = $true
			$handler = [System.Data.SqlClient.SqlInfoMessageEventHandler] { Write-Verbose "$($_)" }
			$conn.add_InfoMessage($handler)
		}
		
		try
		{
			$conn.Open()
		}
		catch
		{
			$ex = $_.Exception
			StatusLog "ERROR: Could not connect to database while running Invoke-SQLCmd2" $ex.Message
		}
		
		$cmd = new-object system.Data.SqlClient.SqlCommand($Query, $conn)
		$cmd.CommandTimeout = $QueryTimeout
		$ds = New-Object system.Data.DataSet
		$da = New-Object system.Data.SqlClient.SqlDataAdapter($cmd)
		[void]$da.fill($ds)
		$conn.Close()
		switch ($As)
		{
			'DataSet'   { Write-Output ($ds) }
			'DataTable' { Write-Output ($ds.Tables) }
			'DataRow'   { Write-Output ($ds.Tables[0]) }
		}
	}
	catch
	{
		$ex = $_.Exception
		StatusLog "ERROR: There was an error while running the Invoke-Sqlcmd2 command" $ex.Message
	}
}

function Get-Type
{
	param ($type)
	
	try
	{
		$types = @(
		'System.Boolean',
		'System.Byte[]',
		'System.Byte',
		'System.Char',
		'System.Datetime',
		'System.Decimal',
		'System.Double',
		'System.Guid',
		'System.Int16',
		'System.Int32',
		'System.Int64',
		'System.Single',
		'System.UInt16',
		'System.UInt32',
		'System.UInt64')
		
		if ($types -contains $type)
		{
			Write-Output "$type"
		}
		else
		{
			Write-Output 'System.String'
			
		}
	}
	catch
	{
		$ex = $_.Exception
		StatusLog "ERROR: There was a error while running the Get-Type command" $ex.Message
	}
}

function Out-DataTable
{
	[CmdletBinding()]
	param ([Parameter(Position = 0, Mandatory = $true, ValueFromPipeline = $true)] [PSObject[]]$InputObject)
	
		Begin
		{
			$dt = new-object System.Data.DataTable
			$First = $true
		}
		Process
		{
			try
			{
				foreach ($object in $InputObject)
				{
					$DR = $DT.NewRow()
					foreach ($property in $object.PsObject.get_properties())
					{
						if ($first)
						{
							$Col = new-object Data.DataColumn
							$Col.ColumnName = $property.Name.ToString()
							if ($property.value)
							{
								if ($property.value -isnot [System.DBNull])
								{
									$Col.DataType = [System.Type]::GetType("$(Get-Type $property.TypeNameOfValue)")
								}
							}
							$DT.Columns.Add($Col)
						}
						if ($property.Gettype().IsArray)
						{
							$DR.Item($property.Name) = $property.value | ConvertTo-XML -AS String -NoTypeInformation -Depth 1
						}
						else
						{
							$DR.Item($property.Name) = $property.value
						}
					}
					$DT.Rows.Add($DR)
					$First = $false
				}
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error during process Out-DataTable" $ex.Message
			}
		}
		
		End
		{
			Write-Output @(, ($dt))
		}
}

function Write-DataTable
{
	[CmdletBinding()]
	param (
		[Parameter(Position = 0, Mandatory = $true)] [string]$ServerInstance,
		[Parameter(Position = 1, Mandatory = $true)] [string]$Database,
		[Parameter(Position = 2, Mandatory = $true)] [string]$TableName,
		[Parameter(Position = 3, Mandatory = $true)] $Data,
		[Parameter(Position = 4, Mandatory = $false)] [string]$Username,
		[Parameter(Position = 5, Mandatory = $false)] [string]$Password,
		[Parameter(Position = 6, Mandatory = $false)] [Int32]$BatchSize = 50000,
		[Parameter(Position = 7, Mandatory = $false)] [Int32]$QueryTimeout = 0,
		[Parameter(Position = 8, Mandatory = $false)] [Int32]$ConnectionTimeout = 15
	)
	
	try
	{
		$conn = new-object System.Data.SqlClient.SQLConnection
		
		if ($Username)
		{ $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance, $Database, $Username, $Password, $ConnectionTimeout }
		else
		{ $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance, $Database, $ConnectionTimeout }
		
		$conn.ConnectionString = $ConnectionString
		
		try
		{
			try
			{
				$conn.Open()
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: Could not connect to database while running the Write-DataTable command" $ex.Message
			}
			
			$bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $connectionString
			$bulkCopy.DestinationTableName = $tableName
			$bulkCopy.BatchSize = $BatchSize
			$bulkCopy.BulkCopyTimeout = $QueryTimeOut
			$bulkCopy.WriteToServer($Data)
			$conn.Close()
		}
		catch
		{
			$ex = $_.Exception
			StatusLog "ERROR: There was an error writing to the database while running Write-DataTable" $ex.Message
			#Write-Error "$ex.Message"
			#continue
		}
	}
	catch
	{
		$ex = $_.Exception
		StatusLog "ERROR: There was an error while running the Write-DataTable command" $ex.Message
	}
}

function Get-LyncEnabledObjects()
{
	try
	{
		$Regex1 = '^(?:tel:)?(?:\+)?(\d+)(?:;ext=(\d+))?(?:;([\w-]+))?$'		
		$Array1 = @()
		
		#Get Users with LineURI
		$Users = Get-CsUser
		if ($Users -ne $null)
		{
			foreach ($item in $Users)
			{
				$Matches = @()
				$Item.LineURI -match $Regex1 | out-null
				
				$myObject1 = New-Object System.Object
				$myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
				$myObject1 | Add-Member -type NoteProperty -name "FirstName" -Value $Item.FirstName
				$myObject1 | Add-Member -type NoteProperty -name "LastName" -Value $Item.LastName
				$myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
				$myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
				$myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
				$myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
				$myObject1 | Add-Member -type NoteProperty -name "Type" -Value "User"
				$Array1 += $myObject1
			}
		}
		
		#Get Users with Private Line
		$UsersPrivateLine = Get-CsUser -Filter { PrivateLine -ne $Null }
		if ($UsersPrivateLine -ne $null)
		{
			foreach ($item in $UsersPrivateLine)
			{
				$Matches = @()
				$Item.PrivateLine -match $Regex1 | out-null
				
				$myObject1 = New-Object System.Object
				$myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
				$myObject1 | Add-Member -type NoteProperty -name "FirstName" -Value $Item.FirstName
				$myObject1 | Add-Member -type NoteProperty -name "LastName" -Value $Item.LastName
				$myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
				$myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.PrivateLine
				$myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
				$myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
				$myObject1 | Add-Member -type NoteProperty -name "Type" -Value "UserPrivateLine"
				$Array1 += $myObject1
			}
		}
		
		#Get analouge lines
		$AnalougeLineURI = Get-CsAnalogDevice
		if ($AnalougeLineURI -ne $null)
		{
			foreach ($item in $AnalougeLineURI)
			{
				$Matches = @()
				$Item.LineURI -match $Regex1 | out-null
				
				$myObject1 = New-Object System.Object
				$myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
				$myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
				$myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
				$myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
				$myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
				$myObject1 | Add-Member -type NoteProperty -name "Type" -Value "AnalougeLine"
				$Array1 += $myObject1
			}
		}
		
		#Get common area phones
		$CommonAreaPhone = Get-CsCommonAreaPhone
		if ($CommonAreaPhone -ne $null)
		{
			foreach ($item in $CommonAreaPhone)
			{
				$Matches = @()
				$Item.LineURI -match $Regex1 | out-null
				
				$myObject1 = New-Object System.Object
				$myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
				$myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
				$myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
				$myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
				$myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
				$myObject1 | Add-Member -type NoteProperty -name "Type" -Value "CommonAreaPhone"
				$Array1 += $myObject1
			}
		}
		
		#Get RGS workflows
		$RGSWorkflow = Get-CsRgsWorkflow
		if ($RGSWorkflow -ne $null)
		{
			foreach ($item in $RGSWorkflow)
			{
				$Matches = @()
				$Item.LineURI -match $Regex1 | out-null
				
				$myObject1 = New-Object System.Object
				$myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
				$myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.PrimaryUri
				$myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
				$myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
				$myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
				$myObject1 | Add-Member -type NoteProperty -name "Type" -Value "RGSWorkflow"
				$Array1 += $myObject1
			}
		}
		
		#Get Exchange UM Contacts
		$ExUmContact = Get-CsExUmContact
		if ($ExUmContact -ne $null)
		{
			foreach ($item in $ExUmContact)
			{
				$Matches = @()
				$Item.LineURI -match $Regex1 | out-null
				
				$myObject1 = New-Object System.Object
				$myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
				$myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
				$myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
				$myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
				$myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
				$myObject1 | Add-Member -type NoteProperty -name "Type" -Value "ExUmContact"
				$Array1 += $myObject1
			}
		}
		
		#Get trusted applications
		$TrustedApplication = Get-CsTrustedApplicationEndpoint
		if ($TrustedApplication -ne $null)
		{
			foreach ($item in $TrustedApplication)
			{
				$Matches = @()
				$Item.LineURI -match $Regex1 | out-null
				
				$myObject1 = New-Object System.Object
				$myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
				$myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
				$myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
				$myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
				$myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
				$myObject1 | Add-Member -type NoteProperty -name "Type" -Value "TrustedApplication"
				$Array1 += $myObject1
			}
		}
		
		#Get conferencing numbers
		$DialInConf = Get-CsDialInConferencingAccessNumber
		if ($DialInConf -ne $null)
		{
			foreach ($Item in $DialInConf)
			{
				$Matches = @()
				$Item.LineURI -match $Regex1 | out-null
				
				$myObject1 = New-Object System.Object
				$myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.DisplayName
				$myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.PrimaryUri
				$myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
				$myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
				$myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
				$myObject1 | Add-Member -type NoteProperty -name "Type" -Value "DialInConf"
				$Array1 += $myObject1
			}
		}
		return $Array1
	}
	catch
	{
		$ex = $_.Exception
		StatusLog "ERROR: There was an error while running the Get-LyncEnabledObjects command" $ex.Message
	}
	
}

function LyncCallAccounting
{
    [CmdletBinding()]  
    param(
    [Parameter(Position=1, Mandatory=$true)] [string]$StartDate,
    [Parameter(Position=2, Mandatory=$true)] [string]$EndDate,
    [Parameter(Position=3, Mandatory=$true)] [string]$CSVExportPath,
    [Parameter(Position=4, Mandatory=$false)] [string]$RateLocalCallingArea='0.00',
    [Parameter(Position=5, Mandatory=$false)] [string]$DbGateways="Drop",  
    [Parameter(Position=6, Mandatory=$false)] [string]$DbUsers="Drop",  
    [Parameter(Position=7, Mandatory=$false)] [String]$DbRateCard="Drop",
    [Parameter(Position=8, Mandatory=$false)] [String]$RateCardCSV=".\RateCard.csv",
    [Parameter(Position=9, Mandatory=$false)] [String]$GatewaysCSV=".\Gateways.csv",
    [Parameter(Position=10, Mandatory=$true)] [String]$ADPath,
    [Parameter(Position=11, Mandatory=$true)] [String]$SQLDataSource_LyncMonitoring,
    [Parameter(Position=12, Mandatory=$false)] [string]$LyncPool,
    [Parameter(Position=13, Mandatory=$false)] [string]$SQLScriptPath=".\LyncCallAccounting.sql",
    [Parameter(Position=14, Mandatory=$false)] [bool]$DebugMode
    ) 
	
	function Create-LyncEnabledObjectsTable
	{
		StatusLog "STEP: Create SQL Table LyncCallAccountingUsers"
		
		try
		{
			#Get Lync numbers then search AD for associated company and department then create SQL table to store
			StatusLog "Finding all Lync enabled objects..."
			try
			{
				$Array2 = @()
				$AssignedNumbers = Get-LyncEnabledObjects
				foreach ($AssignedNumber in $AssignedNumbers)
				{
					$ADMatch = Get-ADObject -SearchBase $ADPath -LDAPFilter "(msrtcsip-primaryuseraddress=$($AssignedNumber.SipAddress))" -Properties name, company, department, msrtcsip-primaryuseraddress
					$myObject2 = New-Object System.Object
					$myObject2 | Add-Member -type NoteProperty -name "LineURI" -Value $AssignedNumber.LineURI
					$myObject2 | Add-Member -type NoteProperty -name "DDI" -Value $AssignedNumber.DDI
					$myObject2 | Add-Member -type NoteProperty -name "Ext" -Value $AssignedNumber.Ext
					$myObject2 | Add-Member -type NoteProperty -name "Type" -Value $AssignedNumber.Type
					$myObject2 | Add-Member -type NoteProperty -name "Name" -Value $AssignedNumber.Name
					$myObject2 | Add-Member -type NoteProperty -name "SipAddress" -Value $AssignedNumber.SipAddress
					$myObject2 | Add-Member -type NoteProperty -name "Company" -Value ([string]$ADMatch.company)
					$myObject2 | Add-Member -type NoteProperty -name "Department" -Value ([string]$ADMatch.department)
					
					$Array2 += $myObject2
					
				}
				$LyncEnabledObjects = $Array2 | Out-DataTable
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error creating the LyncCallAccountingUsers DataTable" $ex.Message
			}
			try
			{
				StatusLog "Creating SQL table LyncCallAccountingUsers..."
				Add-SQLTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingUsers" -DataTable $LyncEnabledObjects -ColumnCollation "Latin1_General_CI_AI"
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error creating the SQL Table LyncCallAccountingUsers" $ex.Message
			}
			try
			{
				StatusLog "Writing DataTable to SQL table LyncCallAccountingUsers..."
				Write-DataTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingUsers" -Data $LyncEnabledObjects
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error writing DataTable to the SQL table LyncCallAccountingUsers" $ex.Message
			}
		}
		catch
		{
			$ex = $_.Exception
			StatusLog "ERROR: There was an error while running Create-LyncEnabledObjectsTable" $ex.Message
		}
	}
	
	function Create-RateCardTable
	{
		try
		{
			StatusLog "STEP: Create SQL table LyncCallAccountingRateCard"
			
			try
			{
				$RateCard = $null
				$RateCard = import-csv $RateCardCSV
			
				if ($RateCard)
				{
					#Import rate card and create SQL table to store
					StatusLog "Importing vendor rate card csv to DataTable..."
					$SQLQueryRateCard = $RateCard | Out-DataTable
				}
				else
				{
					StatusLog "No vendor rate card found, creating empty DataTable..."
					$props1 = @{ Destination = ""; Rate = ""; Country = ""; CallingArea = "" }
					$SQLQueryRateCard = new-object psobject -Property $props1 | Out-DataTable
				}
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error creating the rate card DataTable" $ex.Message
			}
			
			try
			{
				StatusLog "Creating the SQL table LyncCallAccountingRateCard..."
				Add-SQLTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingRateCard" -DataTable $SQLQueryRateCard -ColumnCollation "Latin1_General_CI_AI"
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error creating the SQL table LyncCallAccountingRateCard while running the Add-SQLTable command " $ex.Message
			}
			try
			{
				StatusLog "Writing DataTable to the SQL table LyncCallAccountingRateCard..."
				Write-DataTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingRateCard" -Data $SQLQueryRateCard
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error writing DataTable to the SQL table LyncCallAccountingRateCard while running the Write-DataTable command" $ex.Message
			}
		}
		catch
		{
			$ex = $_.Exception
			StatusLog "ERROR: There was an error while processing the Create-RateCardTable command" $ex.Message
		}
	}
	
	function Create-GatewaysTable
	{
		try
		{
			StatusLog "STEP: Create SQL Table LyncCallAccountingGateways..."
			
			try
			{
				$Gateways = $null
				$Gateways = import-csv $GatewaysCSV
				
				if ($Gateways)
				{
					#Import gateways and create SQL table to store
					StatusLog "Importing vendor gateways csv and creating DataTable..."
					$SQLQueryGateways = $Gateways | Out-DataTable
				}
				else
				{
					StatusLog "No gateways found, creating empty DataTable..."
					$props2 = @{ Vendor = ""; GatewayIP = ""; Country = ""; Location = "" }
					$SQLQueryGateways = new-object psobject -Property $props2 | Out-DataTable
				}
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error creating the gateways DataTable" $ex.Message
			}
			
			try
			{
				StatusLog "Creating the SQL table LyncCallAccountingGateways..."
				Add-SQLTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingGateways" -DataTable $SQLQueryGateways -ColumnCollation "Latin1_General_CI_AI"
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error creating the SQL table LyncCallAccoutingGateways while running the Add-SQLTable command" $ex.Message
			}
			try
			{
				StatusLog "Writing DataTable to the SQL table LyncCallAccountingGateways..."
				Write-DataTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingGateways" -Data $SQLQueryGateways
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error writing DataTable to the SQL table LyncCallAccoutingGateways while running the Write-DataTable command" $ex.Message
			}
		}
		catch
		{
			$ex = $_.Exception
			StatusLog "ERROR: There was an error while running the Create-GatewaysTable command" $ex.Message
		}
	}
	
	function Run-Query
	{
		try
		{
			StatusLog "STEP: Start Lync Call Reports processing"
			
			#Query database existance
			StatusLog "STEP: Check databases"
			try
			{
				$CheckDbGateways = Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "SELECT * FROM tempdb.dbo.LyncCallAccountingGateways" -ErrorAction SilentlyContinue
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "WARNING: The SQL database LyncCallAccountingGateways does not exist or there was an error checking" $ex.Message
			}
			try
			{
				$CheckDbUsers = Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "SELECT * FROM tempdb.dbo.LyncCallAccountingUsers" -ErrorAction SilentlyContinue
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "WARNING: The SQL database LyncCallAccountingUsers does not exist or there was an error checking" $ex.Message
			}
			try
			{
				$CheckDbRateCard = Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "SELECT * FROM tempdb.dbo.LyncCallAccountingRateCard" -ErrorAction SilentlyContinue
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "WARNING: The SQL database LyncCallAccountingRateCard does not exist or there was an error checking" $ex.Message
			}
			#Check LyncCallAccountingGateways
			#If LyncCallAccountingGateways table does not exisit, then create.
			if ($CheckDbGateways -eq $null)
			{
				StatusLog "SQL table LyncCallAccountingGateways does not exist, creating..."
				Create-GatewaysTable
				
			}
			#If LyncCallAccountingGateways table exisits and -DbGateways option is drop, then drop and recreate table (this is the default if no option is selected).
			elseif ($CheckDbGateways -ne $null -and $DbGateways -eq "Drop")
			{
				StatusLog "SQL table LyncCallAccountingGateways already exisits, dropping and recreating..."
				Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingGateways"
				Create-GatewaysTable
				
			}
			#If LyncCallAccountingGateways exisits and -DbGateways option is UseExisting, then use existing table.
			elseif ($CheckDbGateways -ne $null -and $DbGateways -eq "UseExisting")
			{
				StatusLog "Using existing LyncCallAccountingGateways table..."
			}
			else
			{
				StatusLog "WARNING: There was an issue determining if the SQL table LyncCallAccountingGateways exists, atempting to drop and recreate..."
				Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingGateways"
				Create-GatewaysTable
			}
			
			#Check LyncCallAccountingUsers
			#If LyncCallAccountingUsers table does not exisit, then create.
			if ($CheckDbUsers -eq $null)
			{
				StatusLog "SQL table LyncCallAccountingUsers does not exist, creating..."
				Create-LyncEnabledObjectsTable
				
			}
			#If LyncCallAccountingUsers table exisits and -DbUsers option is drop, then drop and recreate table (this is the default if no option is selected).
			elseif ($CheckDbUsers -ne $null -and $DbUsers -eq "Drop")
			{
				StatusLog "SQL table LyncCallAccountingUsers already exisits, dropping and recreating..."
				Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingUsers"
				Create-LyncEnabledObjectsTable
				
			}
			#If LyncCallAccountingUsers exisits and -DbUsers option is UseExisting, then use existing table.
			elseif ($CheckDbUsers -ne $null -and $DbUsers -eq "UseExisting")
			{
				StatusLog "Using existing LyncCallAccountingUsers table..."
				
			}
			else
			{
				StatusLog "WARNING: There was an issue determining if the SQL table LyncCallAccountingUsers exisits, atempting to drop and recreate..."
				Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingUsers"
				Create-LyncEnabledObjectsTable
			}
			
			#Check LyncCallAccountingRateCard
			#If LyncCallAccountingRateCard table does not exisit, then create.
			if ($CheckDbRateCard -eq $null)
			{
				StatusLog "SQL table LyncCallAccountingRateCard does not exist, creating..."
				Create-RateCardTable
				
			}
			#If LyncCallAccountingRateCard table exisits and -DbRateCard option is drop, then drop and recreate table (this is the default if no option is selected).
			elseif ($CheckDbRateCard -ne $null -and $DbRateCard -eq "Drop")
			{
				StatusLog "SQL table LyncCallAccountingRateCard already exisits, dropping and recreating..."
				Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingRateCard"
				Create-RateCardTable
				
			}
			#If LyncCallAccountingRateCard exisits and -DbRateCard option is UseExisting, then use existing table.
			elseif ($CheckDbRateCard -ne $null -and $DbRateCard -eq "UseExisting")
			{
				StatusLog "Using existing LyncCallAccountingRateCard table..."	
			}
			else
			{
				StatusLog "WARNING: There was an issue determining if the SQL table LyncCallAccountingRateCard exisits, atempting to drop and recreate..."
				Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingRateCard"
				Create-RateCardTable
			}
			
			#Run LcsCDR query
			StatusLog "STEP: Run CDR SQL query - this may take some time to complete depending on record volume..."
			try
			{
				
				$LcsCDRQuery = [IO.File]::ReadAllText($SQLScriptPath) -replace "PSvar_StartDate", $StartDate -replace "PSvar_EndDate", $EndDate -replace "'PSvar_RateLocalCallingArea'", $RateLocalCallingArea #CDR query
				$script:CDR = Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_LcsCDR -Query $LcsCDRQuery
				
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error running the LcsCDR database query" $ex.Message
			}
			
			##Output##			
			try
			{
				StatusLog "Creating output file ($CSVExportPath)..."
				$CDR | export-csv $CSVExportPath -NoTypeInformation
				
			}
			catch
			{
				$ex = $_.Exception
				StatusLog "ERROR: There was an error saving the csv export file - Please check the path is correct and you have the required permissions" $ex.Message
			}
			
			#Echo Time elapsed
			StatusLog "STEP: All Done!!"
			StatusLog "Elapsed Time: $(((Get-Date)-$startDTM).totalseconds) seconds"
			
			#Feedback
			StatusLog "To help improve this free tool, please remember to provide feedback at http://www.lync.geek.nz/p/call-accounting.html"
		}
		catch
		{
			$ex = $_.Exception
			StatusLog "ERROR: An error occured during processing - Please review the status log for further details; if you require detailed error messages enable debug mode" $ex.Message
		}
		
	}
    Import-RequiredModules   
    Run-Query
}
##SCRIPT PARAMETERS
$Date = Get-Date
$DateFileName = $Date.ToString("dd-MM-yyyy-HH:mm:ss").Replace(":",".")
$StartDate = "2014-02-03 00:00:00.00"
$EndDate = "2014-02-04 23:59:59.999" 
#$StartDate = ($Date).AddDays(-1)
#$StartDate = $StartDate.ToString("yyyy-MM-dd HH:mm:ss.ff")
#$EndDate = $Date.ToString("yyyy-MM-dd HH:mm:ss.ff")

LyncCallAccounting `
-StartDate $StartDate `
-EndDate $EndDate `
-CSVExportPath "C:\$DateFileName-LyncCDRs.csv" `
-RateLocalCallingArea "0.03" `
-DbGateways "Drop" `
-DbUsers "Drop" `
-DbRateCard "Drop" `
-RateCardCSV "C:\Scripts\LyncCallAccounting\RateCard.csv" `
-GatewaysCSV "C:\Scripts\LyncCallAccounting\Gateways.csv" `
-ADPath "DC=domain,DC=co,DC=nz" `
-SQLDataSource_LyncMonitoring "lyncsql\LYNCMON" `
-LyncPool "lyncpool.domain.co.nz" `
-SQLScriptPath "LyncCallAccounting.sql" `
-DebugMode $true
