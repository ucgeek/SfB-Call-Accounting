﻿#
# This script queries the Lync CDR database (LcsCDR) calculating useful information for call accounting
#
# AUTHOR: Andrew Morpeth
# DATE: 29th June 2014
# VERSION: v2.0
# INFORMATION: http://www.lync.geek.nz/p/call-accounting.html
#
# VERSION HISTORY
#    V 0.2 - Feb 2014 - beta: 1st release
#    V 0.3 - Feb 2014 - beta: Moved data processing to SQL using temporay tables
#    V 0.4 - Mar 2014 - beta: Moved functions outside of script
#    V 0.5 - Mar 2014 - beta: Added vendor rate card lookup and csv gateway import
#    V 0.6 - Mar 2014 - beta: Added support for Lync 2010 Monitoring server reports
#    V 0.7 - Mar 2014 - beta: Removed requirement for vendor rate card and gateways csv. If RateCard.csv or Gateways.csv dont exist and empty table will be created.
#    V 1.0 - Mar 2014 - beta: Added call cost calculations, commented SQL query, prepared restructured version for release
#    V 2.0 - June 2014 - stable: Minor bug fixes and improvements, tested in production for 3 months
#
# NOTES
#    - Tested on Lync 2013 FE with SQL 2008 R2 and SQL 2012 monitoring databases and Lync 2010 FE with SQL 2008 R2 monitoring databases 
#    - Tested with a user account with Domain Admin and SQL sysadmin rights
#
# PREREQUISITES
# The script should be run from a Lync Front End server with the follow pre-requisites: 
#    - SQL Server Management Studio installed or Shared Management Objects.msi from the SQL Server feature pack
#    - User account which is a member of CSAdministrator and is a SQL db_owner or sysadmin
#
# USE (example below)
# LyncCallAccounting `
# -StartDate <Start Date> `
# -EndDate <End Date> `
# -CSVExportPath <File Path to save CSV> `
# -RateLocalCallingArea <Rate for local calls e.g. 0.05> `
# -DbGateways <optional: DROP|UseExisting> `
# -DbUsers <optional: DROP|UseExisting> `
# -DbRateCard <optional: DROP|UseExisting> `
# -RateCardCSV <File Path to RateCard CSV file> `
# -GatewaysCSV <File Path to Gateways CSV file> `
# -ADPath <AD search scope for Lync objects e.g. DC=domain,DC=co,DC=nz> `
# -SQLDataSource_LyncMonitoring <Monitoring SQL server e.g. MonitoringDbServer\Instance> `
# -LyncPool <Lync Pool FQDN>
#
# This script is provided as-is, no warranty is provided or implied. The author is NOT responsible for any damages or data loss that may occur
# through the use of this script.  Always test before using in a production environment. This script is free to use for both personal and 
# business use, however, it may not be sold or included as part of a package that is for sale. A Service Provider may include this script 
# as part of their service offering/best practices provided they only charge for their time to implement and support. 
#
###########################################################################

##SETTINGS
$startDTM = (Get-Date) #Get script start time
$SQLDatabase_LcsCDR = "LcsCDR" #Database to query. LcsCDR is the Lync monitoring CDR database.
$SQLDatabase_tempdb = "tempdb" #Database to create temporary tables
$SQLScriptPath = (Get-Location).Path + ".\LyncCallAccounting.sql"

#LOAD FUNCTIONS
. .\functions\Invoke-SQLCmd2.ps1
. .\functions\Add-SQLTable.ps1
. .\functions\Out-DataTable.ps1
. .\functions\Write-DataTable.ps1
. .\functions\Get-LyncEnabledObjects.ps1

function LyncCallAccounting
{
    [CmdletBinding()]  
    param(
    [Parameter(Position=1, Mandatory=$true)] [string]$StartDate,
    [Parameter(Position=2, Mandatory=$true)] [string]$EndDate,
    [Parameter(Position=3, Mandatory=$true)] [string]$CSVExportPath,
    [Parameter(Position=4, Mandatory=$false)] [string]$RateLocalCallingArea='0.00',
    [Parameter(Position=5, Mandatory=$false)] [string]$DbGateways="Drop",  
    [Parameter(Position=6, Mandatory=$false)] [string]$DbUsers="Drop",  
    [Parameter(Position=7, Mandatory=$false)] [String]$DbRateCard="Drop",
    [Parameter(Position=8, Mandatory=$false)] [String]$RateCardCSV=".\RateCard.csv",
    [Parameter(Position=9, Mandatory=$false)] [String]$GatewaysCSV=".\Gateways.csv",
    [Parameter(Position=10, Mandatory=$true)] [String]$ADPath,
    [Parameter(Position=11, Mandatory=$true)] [String]$SQLDataSource_LyncMonitoring,
    [Parameter(Position=12, Mandatory=$false)] [string]$LyncPool
    ) 

    function Import-RequiredModules
    {
        #Import Lync module
        if (Get-Command New-CsExUmContact -errorAction SilentlyContinue)
        {
            write-host "Lync Commandlets already loaded...`n" -ForegroundColor Green
        }
        else
        {
            if (get-module -ListAvailable | where {$_.name -eq "Lync"})
            {
                write-host "Loading Lync Commandlets (Import-Module Lync)...`n" -ForegroundColor DarkYellow
                Import-Module Lync
            }
            elseif ($LyncPool)
            {
                #Remote connect to Lync if you are not running the script on a Lync server. Note that you may need to enable PS Remoting on the remote Lync server - Enable-PSRemoting (as admin)
                write-host "Loading Lync Commandlets (PS Remoting)...`n" -ForegroundColor DarkYellow
                $RemoteLync2013Session = New-PSSession -ConnectionUri https://$LyncPool/OCSPowerShell/ -Authentication Negotiate #-Credential (Get-credential)
                Import-PSSession $RemoteLync2013Session
            }
        }

        #Import AD module
        #Import Active Directory module (if not using PS 3.0 this is required. Importing module requires Remote Server Administration Tools > Role Administration Tools > AD DS and AD LDS Tools > Active Directory Module for Windows PowerShell to be installed)
        if (Get-Command New-ADObject -errorAction SilentlyContinue)
        {
            write-host "AD Commandlets already loaded...`n" -ForegroundColor Green
        }
        else
        {
            if (get-module -ListAvailable | where {$_.name -eq "ActiveDirectory"})
            {
                write-host "Loading AD Commandlets (Import-Module ActiveDirectory)...`n" -ForegroundColor DarkYellow
                Import-Module ActiveDirectory
            }
            else
            {
                write-host "Unable to load ActiveDirectory module...`n" -ForegroundColor DarkYellow
            }
        }
    }

    function Create-LyncEnabledObjectsTable
    {
        #Get Lync numbers then search AD for associated company and department then create SQL table to store
        write-host "Getting Lync enabled objects and writing to SQL table...`n"
        $Array2 = @()                          
        $AssignedNumbers = Get-LyncEnabledObjects
        foreach($AssignedNumber in $AssignedNumbers)
        {
            $ADMatch = Get-ADObject -SearchBase $ADPath -LDAPFilter "(msrtcsip-primaryuseraddress=$($AssignedNumber.SipAddress))" -Properties name, company, department, msrtcsip-primaryuseraddress
            $myObject2 = New-Object System.Object
            $myObject2 | Add-Member -type NoteProperty -name "LineURI" -Value $AssignedNumber.LineURI
            $myObject2 | Add-Member -type NoteProperty -name "DDI" -Value $AssignedNumber.DDI
            $myObject2 | Add-Member -type NoteProperty -name "Ext" -Value $AssignedNumber.Ext
            $myObject2 | Add-Member -type NoteProperty -name "Type" -Value $AssignedNumber.Type
            $myObject2 | Add-Member -type NoteProperty -name "Name" -Value $AssignedNumber.Name
            $myObject2 | Add-Member -type NoteProperty -name "SipAddress" -Value $AssignedNumber.SipAddress
            $myObject2 | Add-Member -type NoteProperty -name "Company" -Value ([string]$ADMatch.company)
            $myObject2 | Add-Member -type NoteProperty -name "Department" -Value ([string]$ADMatch.department)

            $Array2 += $myObject2

        }
        $LyncEnabledObjects = $Array2 | Out-DataTable
        Add-SQLTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingUsers" -DataTable $LyncEnabledObjects -ColumnCollation "Latin1_General_CI_AI"
        Write-DataTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingUsers" -Data $LyncEnabledObjects
    }

    function Create-RateCardTable
    {
        $RateCard = $null
        $RateCard = import-csv $RateCardCSV

        if($RateCard)
        {
            #Import rate card and create SQL table to store
            write-host "Importing vendor rate card to SQL table...`n"
            $SQLQueryRateCard = $RateCard | Out-DataTable
        }
        else
        {
            write-host "No vendor rate card found, creating empty SQL table...`n"
            $props1 = @{Destination = ""; Rate = ""; Country = ""; CallingArea = ""}
            $SQLQueryRateCard = new-object psobject -Property $props1 | Out-DataTable
        }
        Add-SQLTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingRateCard" -DataTable $SQLQueryRateCard -ColumnCollation "Latin1_General_CI_AI"
        Write-DataTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingRateCard" -Data $SQLQueryRateCard
    }

    function Create-GatewaysTable
    {
        $Gateways = $null
        $Gateways = import-csv $GatewaysCSV
    
        if($Gateways)
        {
            #Import gateways and create SQL table to store
            write-host "Importing vendor gateways card to SQL table...`n"
            $SQLQueryGateways = $Gateways | Out-DataTable
        }
        else
        {
            write-host "No gateways found, creating empty SQL table...`n"
            $props2 = @{Vendor = ""; GatewayIP = ""; Country = ""; Location = ""}
            $SQLQueryGateways = new-object psobject -Property $props2 | Out-DataTable
        }
        Add-SQLTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingGateways" -DataTable $SQLQueryGateways -ColumnCollation "Latin1_General_CI_AI"
        Write-DataTable -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -TableName "LyncCallAccountingGateways" -Data $SQLQueryGateways
    }

    function Run-Query
    {
        #Query database existance
        $CheckDbGateways = Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "SELECT * FROM tempdb.dbo.LyncCallAccountingGateways" -ErrorAction SilentlyContinue
        $CheckDbUsers = Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "SELECT * FROM tempdb.dbo.LyncCallAccountingUsers" -ErrorAction SilentlyContinue
        $CheckDbRateCard = Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "SELECT * FROM tempdb.dbo.LyncCallAccountingRateCard" -ErrorAction SilentlyContinue

    #Check LyncCallAccountingGateways
        #If LyncCallAccountingGateways table does not exisit, then create.
        if($CheckDbGateways -eq $null)
        {
            write-host "SQL table LyncCallAccountingGateways does not exist, creating...`n"
            Create-GatewaysTable
        }
        #If LyncCallAccountingGateways table exisits and -DbGateways option is drop, then drop and recreate table (this is the default if no option is selected).
        elseif($CheckDbGateways -ne $null -and $DbGateways -eq "Drop")
        {
            write-host "SQL table LyncCallAccountingGateways already exisits, dropping and recreating...`n"
            Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingGateways"
            Create-GatewaysTable
        }
        #If LyncCallAccountingGateways exisits and -DbGateways option is UseExisting, then use existing table.
        elseif($CheckDbGateways -ne $null -and $DbGateways -eq "UseExisting")
        {
            write-host "Using existing LyncCallAccountingGateways table...`n"
        }

    #Check LyncCallAccountingUsers
        #If LyncCallAccountingUsers table does not exisit, then create.
        if($CheckDbUsers -eq $null)
        {
            write-host "SQL table LyncCallAccountingUsers does not exist, creating...`n"
            Create-LyncEnabledObjectsTable
        }
        #If LyncCallAccountingUsers table exisits and -DbUsers option is drop, then drop and recreate table (this is the default if no option is selected).
        elseif($CheckDbUsers -ne $null -and $DbUsers -eq "Drop")
        {
            write-host "SQL table LyncCallAccountingUsers already exisits, dropping and recreating...`n"
            Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingUsers"
            Create-LyncEnabledObjectsTable
        }
        #If LyncCallAccountingUsers exisits and -DbUsers option is UseExisting, then use existing table.
        elseif($CheckDbUsers -ne $null -and $DbUsers -eq "UseExisting")
        {
            write-host "Using existing LyncCallAccountingUsers table...`n"
        }

    #Check LyncCallAccountingRateCard
        #If LyncCallAccountingRateCard table does not exisit, then create.
        if($CheckDbRateCard -eq $null)
        {
            write-host "SQL table LyncCallAccountingRateCard does not exist, creating...`n"
            Create-RateCardTable
        }
        #If LyncCallAccountingRateCard table exisits and -DbRateCard option is drop, then drop and recreate table (this is the default if no option is selected).
        elseif($CheckDbRateCard -ne $null -and $DbRateCard -eq "Drop")
        {
            write-host "SQL table LyncCallAccountingRateCard already exisits, dropping and recreating...`n"
            Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_tempdb -Query "DROP TABLE LyncCallAccountingRateCard"
            Create-RateCardTable
        }
        #If LyncCallAccountingRateCard exisits and -DbRateCard option is UseExisting, then use existing table.
        elseif($CheckDbRateCard -ne $null -and $DbRateCard -eq "UseExisting")
        {
            write-host "Using existing LyncCallAccountingRateCard table...`n"
        }

        #Run LcsCDR query
        write-host "Running CDR SQL query, this may take some time to complete depending on record volume...`n"
        $LcsCDRQuery = [IO.File]::ReadAllText($SQLScriptPath) -replace "PSvar_StartDate", $StartDate -replace "PSvar_EndDate", $EndDate -replace "'PSvar_RateLocalCallingArea'", $RateLocalCallingArea #CDR query
        $CDR = Invoke-SQLCmd2 -ServerInstance $SQLDataSource_LyncMonitoring -Database $SQLDatabase_LcsCDR -Query $LcsCDRQuery

        ##Output##
        write-host "Processing of SQL query results completed, creating output file ($CSVExportPath)...`n"
        $CDR | export-csv $CSVExportPath -NoTypeInformation

        #Echo Time elapsed
        "Elapsed Time: $(((Get-Date)-$startDTM).totalseconds) seconds`n"

        #Feedback
        write-host "Please remember to provide feedback at http://www.lync.geek.nz/p/call-accounting.html" -ForegroundColor Red
    }

    Import-RequiredModules
    Run-Query
}


##SCRIPT PARAMETERS
$Date = Get-Date
$DateFileName = $Date.ToString("dd-MM-yyyy-HH:mm:ss").Replace(":",".")
$StartDate = "2014-02-03 00:00:00.00"
$EndDate = "2014-02-04 23:59:59.999" 
#$StartDate = ($Date).AddDays(-1)
#$StartDate = $StartDate.ToString("yyyy-MM-dd HH:mm:ss.ff")
#$EndDate = $Date.ToString("yyyy-MM-dd HH:mm:ss.ff")

LyncCallAccounting `
-StartDate $StartDate `
-EndDate $EndDate `
-CSVExportPath "C:\$DateFileName-LyncCDRs.csv" `
-RateLocalCallingArea "0.03" `
-DbGateways "Drop" `
-DbUsers "Drop" `
-DbRateCard "Drop" `
-RateCardCSV "C:\Scripts\LyncCallAccounting\RateCard.csv" `
-GatewaysCSV "C:\Scripts\LyncCallAccounting\Gateways.csv" `
-ADPath "DC=domain,DC=co,DC=nz" `
-SQLDataSource_LyncMonitoring "lyncsql\LYNCMON" `
-LyncPool "lyncpool.domain.co.nz"