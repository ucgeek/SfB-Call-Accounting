#
# AUTHOR: Andrew Morpeth
# DATE: 2014 
# VERSION: 1.0
#
# Blog - http://www.lync.geek.nz/
#
# ABOUT
# This function returns all Lync enabled objects:
#    Users, Analouge Lines, Common Area Phones, RGS Workflows, Exchange UM Contacts, Trusted Applications and Conferencing Numbers
#
# This script is provided as-is, no warrenty is provided or implied.The author is NOT responsible for any damages or data loss that may occur
# through the use of this script.  Always test before using in a production environment. This script is free to use for both personal and 
# business use, however, it may not be sold or included as part of a package that is for sale. A Service Provider may include this script 
# as part of their service offering/best practices provided they only charge for their time to implement and support.
#
###########################################################################

function Get-LyncEnabledObjects()
{
    $Regex1 = '^(?:tel:)?(?:\+)?(\d+)(?:;ext=(\d+))?(?:;([\w-]+))?$'

    $Array1 = @()

    #Get Users with LineURI
    $Users = Get-CsUser
    if($Users -ne $null)
    {
        foreach($item in $Users)
        {                  
            $Matches = @()
            $Item.LineURI -match $Regex1 | out-null
            
            $myObject1 = New-Object System.Object
            $myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
            $myObject1 | Add-Member -type NoteProperty -name "FirstName" -Value $Item.FirstName
            $myObject1 | Add-Member -type NoteProperty -name "LastName" -Value $Item.LastName
            $myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
            $myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
            $myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
            $myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
            $myObject1 | Add-Member -type NoteProperty -name "Type" -Value "User"
            $Array1 += $myObject1          
        }
    }

    #Get Users with Private Line
    $UsersPrivateLine = Get-CsUser -Filter {PrivateLine -ne $Null} 
    if($UsersPrivateLine -ne $null)
    {
        foreach($item in $UsersPrivateLine)
        {                   
            $Matches = @()
            $Item.PrivateLine -match $Regex1 | out-null
            
            $myObject1 = New-Object System.Object
            $myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
            $myObject1 | Add-Member -type NoteProperty -name "FirstName" -Value $Item.FirstName
            $myObject1 | Add-Member -type NoteProperty -name "LastName" -Value $Item.LastName
            $myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
            $myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.PrivateLine
            $myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
            $myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
            $myObject1 | Add-Member -type NoteProperty -name "Type" -Value "UserPrivateLine"
            $Array1 += $myObject1          
        }
    }

    #Get analouge lines
    $AnalougeLineURI = Get-CsAnalogDevice  
    if($AnalougeLineURI -ne $null)
    {
        foreach($item in $AnalougeLineURI)
        {                  
            $Matches = @()
            $Item.LineURI -match $Regex1 | out-null
            
            $myObject1 = New-Object System.Object
            $myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
            $myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
            $myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
            $myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
            $myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]        
            $myObject1 | Add-Member -type NoteProperty -name "Type" -Value "AnalougeLine"
            $Array1 += $myObject1          
        }
    }

    #Get common area phones
    $CommonAreaPhone = Get-CsCommonAreaPhone 
    if($CommonAreaPhone -ne $null)
    {
        foreach($item in $CommonAreaPhone)
        {                    
            $Matches = @()
            $Item.LineURI -match $Regex1 | out-null

            $myObject1 = New-Object System.Object
            $myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
            $myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress           
            $myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
            $myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
            $myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
            $myObject1 | Add-Member -type NoteProperty -name "Type" -Value "CommonAreaPhone"
            $Array1 += $myObject1          
        }
    }

    #Get RGS workflows
    $RGSWorkflow = Get-CsRgsWorkflow
    if($RGSWorkflow -ne $null)
    {
        foreach($item in $RGSWorkflow)
        {                 
            $Matches = @()
            $Item.LineURI -match $Regex1 | out-null
            
            $myObject1 = New-Object System.Object
            $myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
            $myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.PrimaryUri
            $myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
            $myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
            $myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
            $myObject1 | Add-Member -type NoteProperty -name "Type" -Value "RGSWorkflow"
            $Array1 += $myObject1          
        }
    }

    #Get Exchange UM Contacts
    $ExUmContact = Get-CsExUmContact
    if($ExUmContact -ne $null)
    {
        foreach($item in $ExUmContact)
        {                   
            $Matches = @()
            $Item.LineURI -match $Regex1 | out-null
            
            $myObject1 = New-Object System.Object
            $myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
            $myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
            $myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
            $myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
            $myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
            $myObject1 | Add-Member -type NoteProperty -name "Type" -Value "ExUmContact"
            $Array1 += $myObject1          
        }
    }

    #Get trusted applications
    $TrustedApplication = Get-CsTrustedApplicationEndpoint
    if($TrustedApplication -ne $null)
    {
        foreach($item in $TrustedApplication)
        {                   
            $Matches = @()
            $Item.LineURI -match $Regex1 | out-null
            
            $myObject1 = New-Object System.Object
            $myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.Name
            $myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.SipAddress
            $myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
            $myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
            $myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
            $myObject1 | Add-Member -type NoteProperty -name "Type" -Value "TrustedApplication"
            $Array1 += $myObject1          
        }
    }

    #Get conferencing numbers
    $DialInConf = Get-CsDialInConferencingAccessNumber
    if($DialInConf -ne $null)
    {
        foreach($Item in $DialInConf)
        {                 
            $Matches = @()
            $Item.LineURI -match $Regex1 | out-null
            
            $myObject1 = New-Object System.Object
            $myObject1 | Add-Member -type NoteProperty -name "Name" -Value $Item.DisplayName
            $myObject1 | Add-Member -type NoteProperty -name "SipAddress" -Value $Item.PrimaryUri
            $myObject1 | Add-Member -type NoteProperty -name "LineURI" -Value $Item.LineURI
            $myObject1 | Add-Member -type NoteProperty -name "DDI" -Value $Matches[1]
            $myObject1 | Add-Member -type NoteProperty -name "Ext" -Value $Matches[2]
            $myObject1 | Add-Member -type NoteProperty -name "Type" -Value "DialInConf"
            $Array1 += $myObject1          
        }
    }
    return $Array1
}

#Get-LyncEnabledObjects | FT
#Get-LyncEnabledObjects | export-csv C:\LyncEnabledObjects.csv

